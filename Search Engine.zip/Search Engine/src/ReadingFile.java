import java.io.*;
import java.util.*;

public class ReadingFile {
    private Set<String> stopWords;
    private Map<Integer, String> documentMap; 

    public ReadingFile() {
        stopWords = new HashSet<>();
        documentMap = new HashMap<>();
    }

    public Map<Integer, String> getDocumentMap() {
        return documentMap;
    }

    public void loadStopWords(String stopFile) {
        try (BufferedReader br = new BufferedReader(new FileReader(stopFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                stopWords.add(line.trim().toLowerCase());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadDocuments(String datasetFile, MyList listIndex, MyBST bstIndex) {
        try (BufferedReader br = new BufferedReader(new FileReader(datasetFile))) {
            String line;
            br.readLine(); 
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", 2); 
                if (parts.length < 2 || parts[0].trim().isEmpty() || parts[1].trim().isEmpty()) {
                    
                    continue;
                }
                int docId = Integer.parseInt(parts[0].trim()); 
                String content = parts[1].trim().toLowerCase();
                content = content.replaceAll("[\"']","") 
		                .replaceAll("[,.;:!?()]", " ") 
		                .replaceAll("\\s+", " ") 
		                .trim() 
		                .toLowerCase();
                documentMap.put(docId, content); 
                processLine(content, docId, listIndex, bstIndex);
            }
        } catch (IOException e) {
            System.err.println("Error reading dataset file: " + e.getMessage());
            e.printStackTrace();
        } catch (NumberFormatException e) {
            System.err.println("Invalid document ID format: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void processLine(String line, int docId, MyList listIndex, MyBST bstIndex) {
    	String[] words = line.replaceAll("[,.;:!?()]", " ") 
                .replaceAll("'s\\b", "s")  
                .toLowerCase()
                .split("\\s+"); 
        for (String word : words) {
            if (!stopWords.contains(word) && !word.isEmpty()) {
                listIndex.add(word, docId);
                bstIndex.add(word, docId);
            }
        }
    }
}
