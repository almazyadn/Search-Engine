import java.util.*;

public class Main {
    public static void main(String[] args) {
        MyList listIndex = new MyList();
        MyBST bstIndex = new MyBST();
        ReadingFile reader = new ReadingFile();

        reader.loadStopWords("data/stop.txt");
        reader.loadDocuments("data/dataset.csv", listIndex, bstIndex);

        QueryExecutor qp = new QueryExecutor(reader.getDocumentMap());

        Scanner scanner = new Scanner(System.in);
        String choice;

        System.out.println("################### Search Engine ####################");
        do {
            System.out.println("\nChoose an option:");
            System.out.println("1. Boolean Retrieval (List)");
            System.out.println("2. Boolean Retrieval (BST)");
            System.out.println("3. Ranked Retrieval");
            System.out.println("4. Indexed Documents");
            System.out.println("5. Indexed Tokens");
            System.out.println("q. Quit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    handleBooleanRetrieval(scanner, qp, listIndex, true);
                    break;
                case "2":
                    handleBooleanRetrieval(scanner, qp, bstIndex, false);
                    break;
                case "3":
                    handleRankedRetrieval(scanner, qp);
                    break;
                case "4":
                    showIndexedDocuments(listIndex, bstIndex);
                    break;
                case "5":
                    showIndexedTokens(listIndex, bstIndex);
                    break;
                case "q":
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        } while (!choice.equalsIgnoreCase("q"));

        scanner.close();
    }

    private static void handleBooleanRetrieval(Scanner scanner, QueryExecutor qp, Object index, boolean isList) {
        System.out.println("\n################### Boolean Retrieval ####################");
        System.out.print("\nEnter your query (e.g., term1 AND term2): ");
        String query = scanner.nextLine();
        Set<Integer> result = isList
                ? qp.evaluateBooleanQueryList((MyList) index, query)
                : qp.evaluateBooleanQueryBST((MyBST) index, query);
        System.out.println("Result doc IDs: " + result);
    }

    private static void handleRankedRetrieval(Scanner scanner, QueryExecutor qp) {
        System.out.println("\n################### Ranked Retrieval ###########################");
        System.out.print("\nEnter your query terms (space-separated): ");
        String[] terms = scanner.nextLine().split("\\s+");

        Map<Integer, Integer> results = qp.rankedQuery(terms);
        System.out.println("DocID\tScore");
        for (Map.Entry<Integer, Integer> entry : results.entrySet()) {
            System.out.println(entry.getKey() + "\t" + entry.getValue());
        }
    }

    private static void showIndexedDocuments(MyList listIndex, MyBST bstIndex) {
        System.out.println("\nNumber of Indexed Documents (List): " + listIndex.countDocuments());
        System.out.println("Number of Indexed Documents (BST): " + bstIndex.countDocuments());
    }

    private static void showIndexedTokens(MyList listIndex, MyBST bstIndex) {
        System.out.println("\nNumber of Indexed Tokens (List): " + listIndex.countTokens());
        System.out.println("Number of Indexed Tokens (BST): " + bstIndex.countTokens());
    }
}
